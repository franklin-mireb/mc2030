import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tag } from "lucide-react";
import { useState, useEffect } from "react";

interface CategoryFilterProps {
  selectedCategory: string | null;
  onSelectCategory: (category: string | null) => void;
}

export function CategoryFilter({ selectedCategory, onSelectCategory }: CategoryFilterProps) {
  const [categories, setCategories] = useState<Array<{ id: string; label: string }>>([
    { id: "all", label: "Toutes les catégories" }
  ]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    
    try {
      const stored = localStorage.getItem("mireb_categories");
      if (stored) {
        const loadedCategories = JSON.parse(stored);
        setCategories([
          { id: "all", label: "Toutes les catégories" },
          ...loadedCategories
        ]);
      } else {
        const defaultCategories = [
          { id: "all", label: "Toutes les catégories" },
          { id: "Électronique", label: "Électronique" },
          { id: "Mode", label: "Mode" },
          { id: "Maison", label: "Maison" },
          { id: "Beauté", label: "Beauté" },
          { id: "Sports", label: "Sports" },
          { id: "Jouets", label: "Jouets" },
        ];
        setCategories(defaultCategories);
      }
    } catch (error) {
      console.error("Error loading categories:", error);
    }
  }, []);

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 text-sm font-semibold text-muted-foreground">
        <Tag className="w-4 h-4" />
        <span>Filtrer par catégorie</span>
      </div>
      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex gap-2 pb-2">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              size="sm"
              onClick={() => onSelectCategory(category.id)}
              className="flex-shrink-0"
            >
              {category.label}
            </Button>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
