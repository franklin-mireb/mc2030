import { Product } from "@/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { ShoppingCart, TrendingUp, Star, Flame, Sparkles } from "lucide-react";
import Link from "next/link";

interface ProductCardProps {
  product: Product;
}

const statusConfig = {
  "Vente chaude": { icon: Flame, color: "bg-red-500", label: "Vente chaude" },
  "Meilleure vente": { icon: TrendingUp, color: "bg-blue-500", label: "Meilleure vente" },
  "Vedette": { icon: Star, color: "bg-yellow-500", label: "Vedette" },
  "Nouveauté": { icon: Sparkles, color: "bg-green-500", label: "Nouveauté" },
};

export function ProductCard({ product }: ProductCardProps) {
  const statusInfo = statusConfig[product.status as keyof typeof statusConfig];
  const StatusIcon = statusInfo?.icon;
  
  const safeImages = Array.isArray(product.images) ? product.images : [];
  const mainImage = safeImages.length > 0 ? safeImages[0] : "/placeholder.png";
  const secondaryImages = safeImages.length > 1 ? safeImages.slice(1, 5) : [];

  return (
    <Card className="group overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-300 bg-white dark:bg-gray-800">
      <Link href={`/product/${product.id}`} className="block">
        <div className="relative aspect-square overflow-hidden bg-gray-100 dark:bg-gray-700 cursor-pointer">
          <img
            src={mainImage}
            alt={product.title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          {statusInfo && (
            <Badge className={`absolute top-3 left-3 ${statusInfo.color} text-white border-0 shadow-lg flex items-center gap-1.5 px-3 py-1.5`}>
              {StatusIcon && <StatusIcon className="w-3.5 h-3.5" />}
              <span className="text-xs font-semibold">{statusInfo.label}</span>
            </Badge>
          )}
        </div>
      </Link>

      <CardContent className="p-4 space-y-2">
        <Link href={`/product/${product.id}`} className="block hover:text-orange-600 transition-colors">
          <h3 className="font-semibold text-base line-clamp-2 min-h-[3rem]">
            {product.title}
          </h3>
        </Link>

        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-bold text-orange-600">
                ${product.price}
              </span>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              MOQ: {product.moq} unités
            </p>
          </div>
        </div>

        {secondaryImages.length > 0 && (
          <div className="grid grid-cols-4 gap-1.5 mt-3">
            {secondaryImages.map((img, idx) => (
              <Link key={idx} href={`/product/${product.id}`} className="block">
                <img
                  src={img}
                  alt={`${product.title} ${idx + 2}`}
                  className="w-full aspect-square object-cover rounded border border-gray-200 dark:border-gray-600 hover:border-orange-500 transition-colors cursor-pointer"
                />
              </Link>
            ))}
          </div>
        )}
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <Link href={`/product/${product.id}`} className="w-full">
          <Button className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white shadow-md hover:shadow-lg transition-all duration-300 font-semibold">
            <ShoppingCart className="w-4 h-4 mr-2" />
            Commander
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
