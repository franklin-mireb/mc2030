import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Flame, Trophy, Star, Sparkles } from "lucide-react";

const statuses = [
  { id: "all", label: "Tous les statuts", icon: null },
  { id: "Vente chaude", label: "Vente chaude", icon: Flame },
  { id: "Meilleure vente", label: "Meilleure vente", icon: Trophy },
  { id: "Vedette", label: "Vedette", icon: Star },
  { id: "Nouveauté", label: "Nouveauté", icon: Sparkles },
];

interface StatusFilterProps {
  selectedStatus: string | null;
  onSelectStatus: (status: string | null) => void;
}

export function StatusFilter({ selectedStatus, onSelectStatus }: StatusFilterProps) {
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 text-sm font-semibold text-muted-foreground">
        <Star className="w-4 h-4" />
        <span>Filtrer par statut</span>
      </div>
      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex gap-2 pb-2">
          {statuses.map((status) => {
            const Icon = status.icon;
            return (
              <Button
                key={status.id}
                variant={selectedStatus === status.id ? "default" : "outline"}
                size="sm"
                onClick={() => onSelectStatus(status.id)}
                className="flex-shrink-0"
              >
                {Icon && <Icon className="w-4 h-4 mr-1" />}
                {status.label}
              </Button>
            );
          })}
        </div>
      </ScrollArea>
    </div>
  );
}