
import Link from "next/link";
import { useRouter } from "next/router";
import { Home, Grid3x3, MessageCircle, Handshake, Settings } from "lucide-react";

export function MobileNav() {
  const router = useRouter();
  
  const navItems = [
    { href: "/", icon: Home, label: "Maison" },
    { href: "/categories", icon: Grid3x3, label: "Catégories" },
    { href: "/chat", icon: MessageCircle, label: "Chat" },
    { href: "/partnership", icon: Handshake, label: "Partenariat" },
    { href: "/admin", icon: Settings, label: "Admin" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 z-50 md:hidden">
      <div className="flex items-center justify-around h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = router.pathname === item.href;
          
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${
                isActive
                  ? "text-primary"
                  : "text-gray-600 dark:text-gray-400 hover:text-primary"
              }`}
            >
              <Icon className="w-6 h-6 mb-1" />
              <span className="text-xs">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
