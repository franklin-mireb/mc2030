
import { Delivery } from "@/types";
import { supabase } from "@/lib/supabase";

export const getDeliveries = async (): Promise<Delivery[]> => {
  try {
    const { data, error } = await supabase
      .from("deliveries")
      .select("*")
      .order("createdAt", { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error("Error fetching deliveries:", error);
    return [];
  }
};

export const getDeliveryById = async (id: string): Promise<Delivery | null> => {
  try {
    const { data, error } = await supabase
      .from("deliveries")
      .select("*")
      .eq("id", id)
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error("Error fetching delivery:", error);
    return null;
  }
};

export const getDeliveriesByOrder = async (orderId: string): Promise<Delivery[]> => {
  try {
    const { data, error } = await supabase
      .from("deliveries")
      .select("*")
      .eq("orderId", orderId)
      .order("createdAt", { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error("Error fetching deliveries by order:", error);
    return [];
  }
};

export const createDelivery = async (delivery: Omit<Delivery, "id" | "createdAt">): Promise<Delivery | null> => {
  try {
    const { data, error } = await supabase
      .from("deliveries")
      .insert([
        {
          ...delivery,
          createdAt: new Date().toISOString(),
        },
      ])
      .select()
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error("Error creating delivery:", error);
    return null;
  }
};

export const updateDelivery = async (id: string, updates: Partial<Delivery>): Promise<Delivery | null> => {
  try {
    const { data, error } = await supabase
      .from("deliveries")
      .update(updates)
      .eq("id", id)
      .select()
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error("Error updating delivery:", error);
    return null;
  }
};

export const updateDeliveryStatus = async (
  id: string,
  status: Delivery["status"]
): Promise<Delivery | null> => {
  try {
    const { data, error } = await supabase
      .from("deliveries")
      .update({ status })
      .eq("id", id)
      .select()
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error("Error updating delivery status:", error);
    return null;
  }
};

export const deleteDelivery = async (id: string): Promise<boolean> => {
  try {
    const { error } = await supabase
      .from("deliveries")
      .delete()
      .eq("id", id);

    if (error) throw error;
    return true;
  } catch (error) {
    console.error("Error deleting delivery:", error);
    return false;
  }
};

export const getDeliveriesByStatus = async (status: Delivery["status"]): Promise<Delivery[]> => {
  try {
    const { data, error } = await supabase
      .from("deliveries")
      .select("*")
      .eq("status", status)
      .order("createdAt", { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error("Error fetching deliveries by status:", error);
    return [];
  }
};
