
import { Customer } from "@/types";
import { supabase } from "@/lib/supabase";

export const getCustomers = async (): Promise<Customer[]> => {
  try {
    const { data, error } = await supabase
      .from("customers")
      .select("*")
      .order("createdAt", { ascending: false });

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error("Error fetching customers:", error);
    return [];
  }
};

export const getCustomerById = async (id: string): Promise<Customer | null> => {
  try {
    const { data, error } = await supabase
      .from("customers")
      .select("*")
      .eq("id", id)
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error("Error fetching customer:", error);
    return null;
  }
};

export const getCustomerByPhone = async (phone: string): Promise<Customer | null> => {
  try {
    const { data, error } = await supabase
      .from("customers")
      .select("*")
      .eq("phone", phone)
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error("Error fetching customer by phone:", error);
    return null;
  }
};

export const createCustomer = async (customer: Omit<Customer, "id" | "createdAt">): Promise<Customer | null> => {
  try {
    const { data, error } = await supabase
      .from("customers")
      .insert([
        {
          ...customer,
          createdAt: new Date().toISOString(),
        },
      ])
      .select()
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error("Error creating customer:", error);
    return null;
  }
};

export const updateCustomer = async (id: string, updates: Partial<Customer>): Promise<Customer | null> => {
  try {
    const { data, error } = await supabase
      .from("customers")
      .update(updates)
      .eq("id", id)
      .select()
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error("Error updating customer:", error);
    return null;
  }
};

export const deleteCustomer = async (id: string): Promise<boolean> => {
  try {
    const { error } = await supabase
      .from("customers")
      .delete()
      .eq("id", id);

    if (error) throw error;
    return true;
  } catch (error) {
    console.error("Error deleting customer:", error);
    return false;
  }
};

export const updateCustomerStats = async (
  phone: string,
  orderCount: number,
  totalSpent: number
): Promise<Customer | null> => {
  try {
    const { data, error } = await supabase
      .from("customers")
      .update({
        totalOrders: orderCount,
        totalSpent: totalSpent,
      })
      .eq("phone", phone)
      .select()
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error("Error updating customer stats:", error);
    return null;
  }
};
