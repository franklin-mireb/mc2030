import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MessageCircle, Phone, Clock, MapPin } from "lucide-react";

export default function ChatPage() {
  const whatsappNumber = "+243842267252";
  
  const handleWhatsAppClick = () => {
    const cleanNumber = whatsappNumber.replace(/\+/g, "");
    window.open(`https://wa.me/${cleanNumber}`, "_blank");
  };

  const handleCallClick = () => {
    window.location.href = `tel:${whatsappNumber}`;
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-green-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 py-12">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-full mb-6 shadow-lg">
              <MessageCircle className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-green-600 to-green-500 bg-clip-text text-transparent">
              Contactez-nous
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Notre équipe est à votre disposition pour répondre à toutes vos questions
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-12">
            <Card className="hover:shadow-2xl transition-all duration-300 border-2 border-green-100 dark:border-green-900">
              <CardHeader className="bg-gradient-to-r from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20">
                <CardTitle className="flex items-center gap-3 text-2xl text-green-800 dark:text-green-200">
                  <div className="bg-green-500/20 p-2 rounded-lg">
                    <MessageCircle className="w-6 h-6 text-green-600" />
                  </div>
                  WhatsApp
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <p className="text-gray-600 dark:text-gray-300 text-lg">
                  Discutez avec nous directement sur WhatsApp pour toute question ou commande.
                </p>
                <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800">
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Notre numéro</p>
                  <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                    {whatsappNumber}
                  </p>
                </div>
                <Button
                  onClick={handleWhatsAppClick}
                  className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white text-lg py-6 shadow-lg hover:shadow-xl transition-all duration-300 font-bold"
                >
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Ouvrir WhatsApp
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-2xl transition-all duration-300 border-2 border-primary/20">
              <CardHeader className="bg-gradient-to-r from-primary/10 to-accent/10">
                <CardTitle className="flex items-center gap-3 text-2xl text-primary">
                  <div className="bg-primary/20 p-2 rounded-lg">
                    <Phone className="w-6 h-6 text-primary" />
                  </div>
                  Appel téléphonique
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <p className="text-gray-600 dark:text-gray-300 text-lg">
                  Appelez-nous directement pour une assistance immédiate et personnalisée.
                </p>
                <div className="bg-primary/5 p-4 rounded-lg border border-primary/20">
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Notre numéro</p>
                  <p className="text-2xl font-bold text-primary">
                    {whatsappNumber}
                  </p>
                </div>
                <Button
                  onClick={handleCallClick}
                  className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 text-white text-lg py-6 shadow-lg hover:shadow-xl transition-all duration-300 font-bold"
                >
                  <Phone className="w-5 h-5 mr-2" />
                  Appeler maintenant
                </Button>
              </CardContent>
            </Card>
          </div>

          <Card className="border-2 border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl">
                <Clock className="w-5 h-5 text-primary" />
                Horaires de disponibilité
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-muted/50 p-4 rounded-lg">
                  <p className="font-semibold mb-2">Lundi - Vendredi</p>
                  <p className="text-muted-foreground">8h00 - 18h00</p>
                </div>
                <div className="bg-muted/50 p-4 rounded-lg">
                  <p className="font-semibold mb-2">Samedi - Dimanche</p>
                  <p className="text-muted-foreground">9h00 - 17h00</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="mt-6 bg-gradient-to-r from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 border-2 border-orange-200 dark:border-orange-800">
            <CardContent className="p-6 text-center">
              <MapPin className="w-8 h-8 text-orange-600 mx-auto mb-3" />
              <h3 className="text-lg font-semibold mb-2">Mireb Commercial</h3>
              <p className="text-muted-foreground">
                Votre partenaire de confiance pour tous vos achats en gros
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
