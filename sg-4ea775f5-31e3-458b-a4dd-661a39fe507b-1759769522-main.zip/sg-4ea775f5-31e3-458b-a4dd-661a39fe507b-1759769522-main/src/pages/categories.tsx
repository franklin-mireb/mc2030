
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { categories } from "@/lib/mockData";
import Link from "next/link";
import { Tag, Package, Sparkles, Home as HomeIcon, Shirt, Trophy } from "lucide-react";

const categoryIcons: Record<string, any> = {
  "Électronique": Package,
  "Mode": Shirt,
  "Maison": HomeIcon,
  "Beauté": Sparkles,
  "Sports": Trophy,
  "Jouets": Tag,
};

export default function CategoriesPage() {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8 text-center bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
          Catégories de produits
        </h1>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {categories.filter(cat => cat.id !== "all").map((category) => {
            const Icon = categoryIcons[category.id] || Tag;
            
            return (
              <Link key={category.id} href={`/?category=${category.id}`}>
                <Card className="hover:shadow-lg transition-all hover:scale-105 cursor-pointer border-2 hover:border-primary">
                  <CardContent className="p-6 text-center">
                    <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Icon className="w-8 h-8 text-primary" />
                    </div>
                    <h3 className="font-semibold text-lg">{category.label}</h3>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>
    </Layout>
  );
}
