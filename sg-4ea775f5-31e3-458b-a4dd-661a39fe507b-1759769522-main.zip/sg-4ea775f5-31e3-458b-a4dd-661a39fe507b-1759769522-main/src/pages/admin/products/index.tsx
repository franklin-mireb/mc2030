
import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Link from "next/link";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Product } from "@/types";
import { getProducts, deleteProduct } from "@/lib/localStorage";
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2,
  Flame, 
  Trophy, 
  Star, 
  Sparkles
} from "lucide-react";

const statusConfig = {
  "Vente chaude": { label: "Vente chaude", icon: Flame, color: "bg-red-500" },
  "Meilleure vente": { label: "Meilleure vente", icon: Trophy, color: "bg-yellow-500" },
  "Vedette": { label: "Vedette", icon: Star, color: "bg-purple-500" },
  "Nouveauté": { label: "Nouveauté", icon: Sparkles, color: "bg-green-500" },
};

export default function AdminProductsPage() {
  const router = useRouter();
  const [products, setProducts] = useState<Product[]>([]);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const user = localStorage.getItem("user");
    if (!user) {
      router.push("/admin/login");
      return;
    }

    loadProducts();
  }, [router]);

  const loadProducts = () => {
    const allProducts = getProducts();
    setProducts(allProducts);
  };

  const handleDelete = (productId: string) => {
    if (confirm("Êtes-vous sûr de vouloir supprimer ce produit?")) {
      deleteProduct(productId);
      loadProducts();
    }
  };

  const filteredProducts = products.filter((p) =>
    p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Gestion des produits</h1>
          <Link href="/admin/products/new">
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Nouveau produit
            </Button>
          </Link>
        </div>

        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input
              placeholder="Rechercher un produit..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProducts.map((product) => {
            const status = statusConfig[product.status as keyof typeof statusConfig];
            const StatusIcon = status?.icon || Star;
            const productImage = product.images && product.images.length > 0 
              ? product.images[0] 
              : "/placeholder.png";
            
            return (
              <Card key={product.id}>
                <CardContent className="p-4">
                  <div className="relative mb-3">
                    <img
                      src={productImage}
                      alt={product.title}
                      className="w-full h-48 object-cover rounded-lg"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "/placeholder.png";
                      }}
                    />
                    {status && (
                      <Badge
                        className={`absolute top-2 left-2 ${status.color} text-white flex items-center gap-1`}
                      >
                        <StatusIcon className="w-3 h-3" />
                        {status.label}
                      </Badge>
                    )}
                  </div>
                  
                  <h3 className="font-semibold mb-2 line-clamp-2">
                    {product.title}
                  </h3>
                  
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-lg font-bold text-primary">
                      ${product.price.toLocaleString()}
                    </span>
                    <span className="text-sm text-muted-foreground">
                      MOQ: {product.moq}
                    </span>
                  </div>

                  <Badge variant="secondary" className="mb-3">
                    {product.category}
                  </Badge>

                  <div className="flex gap-2">
                    <Link href={`/admin/products/edit/${product.id}`} className="flex-1">
                      <Button variant="outline" size="sm" className="w-full">
                        <Edit className="w-4 h-4 mr-1" />
                        Modifier
                      </Button>
                    </Link>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDelete(product.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Aucun produit trouvé</p>
          </div>
        )}
      </div>
    </Layout>
  );
}
