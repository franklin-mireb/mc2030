import { useState } from "react";
import { useRouter } from "next/router";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { saveProduct, getProducts } from "@/lib/localStorage";
import { ArrowLeft, Upload, X, Image as ImageIcon } from "lucide-react";
import Link from "next/link";

export default function NewProductPage() {
  const router = useRouter();
  const [mainImagePreview, setMainImagePreview] = useState("");
  const [secondaryPreviews, setSecondaryPreviews] = useState<string[]>(["", "", "", ""]);
  const [formData, setFormData] = useState({
    title: "",
    price: "",
    moq: "",
    mainImage: "",
    secondaryImages: ["", "", "", ""],
    description: "",
    category: "",
    status: "Nouveauté" as "Vente chaude" | "Meilleure vente" | "Vedette" | "Nouveauté",
  });

  const handleMainImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setMainImagePreview(result);
        setFormData({ ...formData, mainImage: result });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSecondaryImageUpload = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        const newPreviews = [...secondaryPreviews];
        newPreviews[index] = result;
        setSecondaryPreviews(newPreviews);
        
        const newImages = [...formData.secondaryImages];
        newImages[index] = result;
        setFormData({ ...formData, secondaryImages: newImages });
      };
      reader.readAsDataURL(file);
    }
  };

  const removeSecondaryImage = (index: number) => {
    const newPreviews = [...secondaryPreviews];
    newPreviews[index] = "";
    setSecondaryPreviews(newPreviews);
    
    const newImages = [...formData.secondaryImages];
    newImages[index] = "";
    setFormData({ ...formData, secondaryImages: newImages });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newProduct = {
      id: `product-${Date.now()}`,
      title: formData.title,
      price: parseFloat(formData.price),
      moq: parseInt(formData.moq),
      images: [formData.mainImage, ...formData.secondaryImages.filter((img) => img !== "")],
      description: formData.description,
      category: formData.category,
      status: formData.status,
      createdAt: new Date().toISOString(),
    };

    saveProduct(newProduct);
    router.push("/admin/products");
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6">
        <div className="mb-6">
          <Link href="/admin/products">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Ajouter un nouveau produit</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Titre du produit *
                </label>
                <Input
                  placeholder="Ex: Smartphone Samsung Galaxy"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Prix ($) *
                  </label>
                  <Input
                    type="number"
                    step="0.01"
                    placeholder="100.00"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    MOQ (Quantité minimale) *
                  </label>
                  <Input
                    type="number"
                    placeholder="1"
                    value={formData.moq}
                    onChange={(e) => setFormData({ ...formData, moq: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Image principale *
                </label>
                <div className="space-y-3">
                  {mainImagePreview && (
                    <div className="relative w-full h-64 rounded-lg overflow-hidden border-2 border-dashed border-primary/20">
                      <img
                        src={mainImagePreview}
                        alt="Aperçu"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  <div className="flex gap-2">
                    <label className="flex-1">
                      <div className="border-2 border-dashed rounded-lg p-4 hover:border-primary transition-colors cursor-pointer">
                        <div className="flex flex-col items-center gap-2">
                          <Upload className="w-8 h-8 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">
                            {mainImagePreview ? "Changer l'image" : "Télécharger une image"}
                          </span>
                        </div>
                      </div>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleMainImageUpload}
                        required={!mainImagePreview}
                      />
                    </label>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Images secondaires (jusqu'à 4)
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[0, 1, 2, 3].map((index) => (
                    <div key={index}>
                      {secondaryPreviews[index] ? (
                        <div className="relative group">
                          <img
                            src={secondaryPreviews[index]}
                            alt={`Image ${index + 1}`}
                            className="w-full h-32 object-cover rounded-lg border-2 border-primary/20"
                          />
                          <button
                            type="button"
                            onClick={() => removeSecondaryImage(index)}
                            className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <label className="block">
                          <div className="border-2 border-dashed rounded-lg h-32 hover:border-primary transition-colors cursor-pointer flex flex-col items-center justify-center gap-2">
                            <ImageIcon className="w-6 h-6 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">Image {index + 1}</span>
                          </div>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => handleSecondaryImageUpload(index, e)}
                          />
                        </label>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Description *
                </label>
                <Textarea
                  placeholder="Décrivez le produit en détail..."
                  rows={5}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                />
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Catégorie *
                  </label>
                  <Input
                    placeholder="Ex: Électronique"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Statut *
                  </label>
                  <Select
                    value={formData.status}
                    onValueChange={(value: any) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Vente chaude">Vente chaude</SelectItem>
                      <SelectItem value="Meilleure vente">Meilleure vente</SelectItem>
                      <SelectItem value="Vedette">Vedette</SelectItem>
                      <SelectItem value="Nouveauté">Nouveauté</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex gap-3">
                <Button type="submit" className="flex-1">
                  Créer le produit
                </Button>
                <Link href="/admin/products">
                  <Button type="button" variant="outline">
                    Annuler
                  </Button>
                </Link>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
