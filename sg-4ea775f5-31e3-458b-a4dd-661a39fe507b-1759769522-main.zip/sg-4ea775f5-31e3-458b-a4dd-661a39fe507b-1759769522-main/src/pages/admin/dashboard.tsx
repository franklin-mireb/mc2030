import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Package, 
  ShoppingCart, 
  Users, 
  TrendingUp,
  Plus,
  Settings,
  FileDown,
  FileUp,
  LogOut,
  Flame,
  Trophy,
  Star,
  Sparkles,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  BarChart3,
  Eye
} from "lucide-react";
import Link from "next/link";
import { getProducts, saveProduct, deleteProduct, getOrders } from "@/lib/localStorage";

export default function AdminDashboardPage() {
  const router = useRouter();
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalOrders: 0,
    newOrders: 0,
    deliveredOrders: 0,
    rejectedOrders: 0,
    postponedOrders: 0,
    unreachableOrders: 0,
    totalCustomers: 0,
    totalRevenue: 0,
    hotProducts: 0,
    bestsellerProducts: 0,
    featuredProducts: 0,
    newProducts: 0,
  });

  const [recentOrders, setRecentOrders] = useState<any[]>([]);
  const [topProducts, setTopProducts] = useState<any[]>([]);

  useEffect(() => {
    const user = localStorage.getItem("user");
    if (!user) {
      router.push("/admin/login");
      return;
    }

    const products = getProducts();
    const orders = getOrders();
    
    const newOrders = orders.filter((o) => o.status === "new");
    const deliveredOrders = orders.filter((o) => o.status === "delivered");
    const rejectedOrders = orders.filter((o) => o.status === "rejected");
    const postponedOrders = orders.filter((o) => o.status === "postponed");
    const unreachableOrders = orders.filter((o) => o.status === "unreachable");
    
    const uniqueCustomers = new Set(orders.map((o) => o.customerPhone));
    const totalRevenue = deliveredOrders.reduce((sum, order) => sum + order.totalPrice, 0);

    const hotProducts = products.filter((p) => p.status === "Vente chaude").length;
    const bestsellerProducts = products.filter((p) => p.status === "Meilleure vente").length;
    const featuredProducts = products.filter((p) => p.status === "Vedette").length;
    const newProducts = products.filter((p) => p.status === "Nouveauté").length;

    const productOrderCounts = new Map();
    orders.forEach((order) => {
      const count = productOrderCounts.get(order.productId) || 0;
      productOrderCounts.set(order.productId, count + 1);
    });

    const topProductsData = Array.from(productOrderCounts.entries())
      .map(([productId, count]) => {
        const product = products.find((p) => p.id === productId);
        return product ? { ...product, orderCount: count } : null;
      })
      .filter(Boolean)
      .sort((a, b) => b!.orderCount - a!.orderCount)
      .slice(0, 5);

    setStats({
      totalProducts: products.length,
      totalOrders: orders.length,
      newOrders: newOrders.length,
      deliveredOrders: deliveredOrders.length,
      rejectedOrders: rejectedOrders.length,
      postponedOrders: postponedOrders.length,
      unreachableOrders: unreachableOrders.length,
      totalCustomers: uniqueCustomers.size,
      totalRevenue,
      hotProducts,
      bestsellerProducts,
      featuredProducts,
      newProducts,
    });

    setRecentOrders(orders.slice(-5).reverse());
    setTopProducts(topProductsData);
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem("user");
    router.push("/admin/login");
  };

  const statusConfig = {
    new: { label: "Nouveau", color: "bg-blue-500", icon: AlertCircle },
    postponed: { label: "Reporté", color: "bg-yellow-500", icon: Clock },
    delivered: { label: "Livré", color: "bg-green-500", icon: CheckCircle2 },
    unreachable: { label: "Injoignable", color: "bg-orange-500", icon: XCircle },
    rejected: { label: "Rejeté", color: "bg-red-500", icon: XCircle },
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Tableau de bord
            </h1>
            <p className="text-muted-foreground mt-1 flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Gestion de Mireb Commercial
            </p>
          </div>
          <Button variant="outline" onClick={handleLogout} className="self-start md:self-auto">
            <LogOut className="w-4 h-4 mr-2" />
            Déconnexion
          </Button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/5 border-blue-200 dark:border-blue-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
                <Package className="w-4 h-4" />
                Produits
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-blue-600 dark:text-blue-400">
                {stats.totalProducts}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Total dans le catalogue</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/5 border-purple-200 dark:border-purple-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
                <ShoppingCart className="w-4 h-4" />
                Commandes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-purple-600 dark:text-purple-400">
                {stats.totalOrders}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Commandes totales</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500/10 to-green-600/5 border-green-200 dark:border-green-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Nouvelles
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-green-600 dark:text-green-400">
                {stats.newOrders}
              </div>
              <p className="text-xs text-muted-foreground mt-1">À traiter maintenant</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500/10 to-orange-600/5 border-orange-200 dark:border-orange-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-muted-foreground flex items-center gap-2">
                <Users className="w-4 h-4" />
                Clients
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-orange-600 dark:text-orange-400">
                {stats.totalCustomers}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Clients uniques</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <Card className="border-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-500" />
                Revenus totaux
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">
                {stats.totalRevenue.toLocaleString()} F
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                {stats.deliveredOrders} commandes livrées
              </p>
            </CardContent>
          </Card>

          <Card className="border-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-blue-500" />
                Statuts des commandes
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm">Livrées</span>
                <Badge className="bg-green-500">{stats.deliveredOrders}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Reportées</span>
                <Badge className="bg-yellow-500">{stats.postponedOrders}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Injoignables</span>
                <Badge className="bg-orange-500">{stats.unreachableOrders}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Rejetées</span>
                <Badge className="bg-red-500">{stats.rejectedOrders}</Badge>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="w-5 h-5 text-yellow-500" />
                Produits par statut
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm flex items-center gap-2">
                  <Flame className="w-4 h-4 text-red-500" />
                  Vente chaude
                </span>
                <Badge className="bg-red-500">{stats.hotProducts}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-yellow-500" />
                  Meilleures ventes
                </span>
                <Badge className="bg-yellow-500">{stats.bestsellerProducts}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm flex items-center gap-2">
                  <Star className="w-4 h-4 text-purple-500" />
                  Vedettes
                </span>
                <Badge className="bg-purple-500">{stats.featuredProducts}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-green-500" />
                  Nouveautés
                </span>
                <Badge className="bg-green-500">{stats.newProducts}</Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Actions rapides</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Link href="/admin/products/new">
                <Button className="w-full justify-start bg-gradient-to-r from-primary to-accent hover:opacity-90">
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter un nouveau produit
                </Button>
              </Link>
              <Link href="/admin/products">
                <Button className="w-full justify-start" variant="outline">
                  <Package className="w-4 h-4 mr-2" />
                  Gérer les produits ({stats.totalProducts})
                </Button>
              </Link>
              <Link href="/admin/orders?status=new">
                <Button className="w-full justify-start" variant="outline">
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Nouvelles commandes ({stats.newOrders})
                </Button>
              </Link>
              <Link href="/admin/customers">
                <Button className="w-full justify-start" variant="outline">
                  <Users className="w-4 h-4 mr-2" />
                  Gérer les clients ({stats.totalCustomers})
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Outils & Paramètres</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full justify-start" variant="outline">
                <FileUp className="w-4 h-4 mr-2" />
                Importer des produits (CSV/Excel)
              </Button>
              <Button className="w-full justify-start" variant="outline">
                <FileDown className="w-4 h-4 mr-2" />
                Exporter le catalogue
              </Button>
              <Link href="/admin/categories">
                <Button className="w-full justify-start" variant="outline">
                  <Settings className="w-4 h-4 mr-2" />
                  Gérer les catégories
                </Button>
              </Link>
              <Button className="w-full justify-start" variant="outline">
                <Settings className="w-4 h-4 mr-2" />
                Personnaliser le thème
              </Button>
            </CardContent>
          </Card>
        </div>

        {topProducts.length > 0 && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-yellow-500" />
                Top 5 Produits les plus commandés
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topProducts.map((product: any, index) => (
                  <div key={product.id} className="flex items-center gap-4 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors">
                    <div className="text-2xl font-bold text-primary w-8">
                      #{index + 1}
                    </div>
                    <img
                      src={product.mainImage}
                      alt={product.title}
                      className="w-16 h-16 rounded-lg object-cover"
                    />
                    <div className="flex-1">
                      <h3 className="font-semibold">{product.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {product.price.toLocaleString()} F CFA
                      </p>
                    </div>
                    <Badge className="bg-primary">
                      {product.orderCount} commande{product.orderCount > 1 ? "s" : ""}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {recentOrders.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-500" />
                Commandes récentes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentOrders.map((order) => {
                  const status = statusConfig[order.status];
                  const StatusIcon = status.icon;
                  return (
                    <div
                      key={order.id}
                      className="flex items-center justify-between p-4 rounded-lg border hover:border-primary transition-colors"
                    >
                      <div className="flex-1">
                        <h3 className="font-semibold">{order.productTitle}</h3>
                        <p className="text-sm text-muted-foreground">
                          {order.customerName} • {order.customerPhone}
                        </p>
                        <p className="text-sm font-semibold text-primary mt-1">
                          {order.totalPrice.toLocaleString()} F CFA
                        </p>
                      </div>
                      <Badge className={`${status.color} text-white flex items-center gap-1`}>
                        <StatusIcon className="w-3 h-3" />
                        {status.label}
                      </Badge>
                    </div>
                  );
                })}
              </div>
              <Link href="/admin/orders">
                <Button className="w-full mt-4" variant="outline">
                  Voir toutes les commandes
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
}
