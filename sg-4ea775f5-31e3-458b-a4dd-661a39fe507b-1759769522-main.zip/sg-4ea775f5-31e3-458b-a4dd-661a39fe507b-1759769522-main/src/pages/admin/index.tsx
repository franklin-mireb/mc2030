import { useEffect } from "react";
import { useRouter } from "next/router";

export default function AdminRootPage() {
  const router = useRouter();

  useEffect(() => {
    const isAdmin = localStorage.getItem("isAdmin");
    const userRole = localStorage.getItem("userRole");

    if (isAdmin === "true") {
      if (userRole === "partner") {
        router.push("/admin/products/new");
      } else {
        router.push("/admin/dashboard");
      }
    } else {
      router.push("/admin/login");
    }
  }, [router]);

  return (
    <div className="min-h-screen flex items-center justify-center">
      <p className="text-gray-500">Redirection...</p>
    </div>
  );
}
