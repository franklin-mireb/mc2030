import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { getOrders, updateOrderStatus } from "@/lib/localStorage";
import { Order } from "@/types";
import {
  Truck,
  Package,
  CheckCircle2,
  Clock,
  XCircle,
  Search,
  MapPin,
  Phone,
  Calendar,
  DollarSign,
  Filter
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function AdminDeliveriesPage() {
  const router = useRouter();
  const [orders, setOrders] = useState<Order[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  useEffect(() => {
    const user = localStorage.getItem("user");
    if (!user) {
      router.push("/admin/login");
      return;
    }

    loadOrders();
  }, [router]);

  const loadOrders = () => {
    const allOrders = getOrders();
    setOrders(allOrders.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    ));
  };

  const getStatusIcon = (status: Order["status"]) => {
    switch (status) {
      case "new":
        return <Clock className="w-5 h-5" />;
      case "delivered":
        return <CheckCircle2 className="w-5 h-5" />;
      case "postponed":
        return <Calendar className="w-5 h-5" />;
      case "unreachable":
        return <XCircle className="w-5 h-5" />;
      case "rejected":
        return <XCircle className="w-5 h-5" />;
      default:
        return <Package className="w-5 h-5" />;
    }
  };

  const getStatusColor = (status: Order["status"]) => {
    switch (status) {
      case "new":
        return "bg-blue-500";
      case "delivered":
        return "bg-green-500";
      case "postponed":
        return "bg-yellow-500";
      case "unreachable":
        return "bg-orange-500";
      case "rejected":
        return "bg-red-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusLabel = (status: Order["status"]) => {
    switch (status) {
      case "new":
        return "Nouveau";
      case "delivered":
        return "Livré";
      case "postponed":
        return "Reporté";
      case "unreachable":
        return "Injoignable";
      case "rejected":
        return "Rejeté";
      default:
        return status;
    }
  };

  const handleUpdateStatus = (orderId: string, newStatus: Order["status"]) => {
    updateOrderStatus(orderId, newStatus);
    loadOrders();
  };

  const filteredOrders = orders.filter((order) => {
    const matchesSearch = 
      order.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customerPhone.includes(searchQuery) ||
      order.customerCity.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.id.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || order.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: orders.length,
    new: orders.filter(o => o.status === "new").length,
    delivered: orders.filter(o => o.status === "delivered").length,
    postponed: orders.filter(o => o.status === "postponed").length,
    problems: orders.filter(o => o.status === "unreachable" || o.status === "rejected").length
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6">
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-2">
            Gestion des livraisons
          </h1>
          <p className="text-muted-foreground flex items-center gap-2">
            <Truck className="w-4 h-4" />
            Suivez et gérez toutes vos livraisons en temps réel
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          <Card className="border-2 hover:border-primary transition-colors cursor-pointer" onClick={() => setStatusFilter("all")}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Package className="w-6 h-6 text-primary/60" />
                <Badge variant="secondary">{stats.total}</Badge>
              </div>
              <h3 className="text-2xl font-bold text-primary">{stats.total}</h3>
              <p className="text-xs text-muted-foreground">Total</p>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-blue-500 transition-colors cursor-pointer" onClick={() => setStatusFilter("new")}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Clock className="w-6 h-6 text-blue-500/60" />
                <Badge className="bg-blue-500">{stats.new}</Badge>
              </div>
              <h3 className="text-2xl font-bold text-blue-600">{stats.new}</h3>
              <p className="text-xs text-muted-foreground">Nouveau</p>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-green-500 transition-colors cursor-pointer" onClick={() => setStatusFilter("delivered")}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <CheckCircle2 className="w-6 h-6 text-green-500/60" />
                <Badge className="bg-green-500">{stats.delivered}</Badge>
              </div>
              <h3 className="text-2xl font-bold text-green-600">{stats.delivered}</h3>
              <p className="text-xs text-muted-foreground">Livré</p>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-yellow-500 transition-colors cursor-pointer" onClick={() => setStatusFilter("postponed")}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Calendar className="w-6 h-6 text-yellow-500/60" />
                <Badge className="bg-yellow-500">{stats.postponed}</Badge>
              </div>
              <h3 className="text-2xl font-bold text-yellow-600">{stats.postponed}</h3>
              <p className="text-xs text-muted-foreground">Reporté</p>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-red-500 transition-colors cursor-pointer" onClick={() => setStatusFilter("unreachable")}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <XCircle className="w-6 h-6 text-red-500/60" />
                <Badge className="bg-red-500">{stats.problems}</Badge>
              </div>
              <h3 className="text-2xl font-bold text-red-600">{stats.problems}</h3>
              <p className="text-xs text-muted-foreground">Problèmes</p>
            </CardContent>
          </Card>
        </div>

        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Rechercher par nom, téléphone, ville ou ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full md:w-[200px]">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Filtrer par statut" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous les statuts</SelectItem>
              <SelectItem value="new">Nouveau</SelectItem>
              <SelectItem value="delivered">Livré</SelectItem>
              <SelectItem value="postponed">Reporté</SelectItem>
              <SelectItem value="unreachable">Injoignable</SelectItem>
              <SelectItem value="rejected">Rejeté</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-4">
          {filteredOrders.map((order) => (
            <Card key={order.id} className="hover:shadow-lg transition-all border-2 hover:border-primary/50">
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Truck className="w-5 h-5 text-primary" />
                      {order.customerName}
                    </CardTitle>
                    <p className="text-sm text-muted-foreground">
                      Commande #{order.id.slice(0, 8)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getStatusColor(order.status)}>
                      {getStatusIcon(order.status)}
                      <span className="ml-1">{getStatusLabel(order.status)}</span>
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div className="space-y-3">
                    <div className="flex items-start gap-2">
                      <Phone className="w-4 h-4 mt-1 text-muted-foreground flex-shrink-0" />
                      <div>
                        <p className="text-sm text-muted-foreground">Téléphone</p>
                        <p className="font-medium">{order.customerPhone}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <MapPin className="w-4 h-4 mt-1 text-muted-foreground flex-shrink-0" />
                      <div>
                        <p className="text-sm text-muted-foreground">Adresse de livraison</p>
                        <p className="font-medium">{order.customerAddress}</p>
                        <p className="text-sm text-muted-foreground">{order.customerCity}</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-start gap-2">
                      <Calendar className="w-4 h-4 mt-1 text-muted-foreground flex-shrink-0" />
                      <div>
                        <p className="text-sm text-muted-foreground">Date de commande</p>
                        <p className="font-medium">
                          {new Date(order.createdAt).toLocaleDateString("fr-FR", {
                            day: "2-digit",
                            month: "long",
                            year: "numeric",
                            hour: "2-digit",
                            minute: "2-digit"
                          })}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <DollarSign className="w-4 h-4 mt-1 text-muted-foreground flex-shrink-0" />
                      <div>
                        <p className="text-sm text-muted-foreground">Montant total</p>
                        <p className="font-bold text-xl text-primary">
                          {order.totalPrice.toLocaleString()} F CFA
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <p className="text-sm text-muted-foreground mb-2">Produit commandé:</p>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-16 h-16 rounded-lg overflow-hidden border-2 flex-shrink-0">
                      <img 
                        src={order.productImage} 
                        alt={order.productTitle}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold truncate">{order.productTitle}</p>
                      <p className="text-sm text-muted-foreground">
                        Quantité: {order.quantity} unité(s)
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Button
                      size="sm"
                      variant={order.status === "new" ? "default" : "outline"}
                      onClick={() => handleUpdateStatus(order.id, "new")}
                      className="flex-1 min-w-[120px]"
                    >
                      <Clock className="w-4 h-4 mr-1" />
                      Nouveau
                    </Button>
                    <Button
                      size="sm"
                      variant={order.status === "delivered" ? "default" : "outline"}
                      onClick={() => handleUpdateStatus(order.id, "delivered")}
                      className="flex-1 min-w-[120px] hover:bg-green-500 hover:text-white"
                    >
                      <CheckCircle2 className="w-4 h-4 mr-1" />
                      Livré
                    </Button>
                    <Button
                      size="sm"
                      variant={order.status === "postponed" ? "default" : "outline"}
                      onClick={() => handleUpdateStatus(order.id, "postponed")}
                      className="flex-1 min-w-[120px] hover:bg-yellow-500 hover:text-white"
                    >
                      <Calendar className="w-4 h-4 mr-1" />
                      Reporté
                    </Button>
                    <Button
                      size="sm"
                      variant={order.status === "unreachable" ? "default" : "outline"}
                      onClick={() => handleUpdateStatus(order.id, "unreachable")}
                      className="flex-1 min-w-[120px] hover:bg-orange-500 hover:text-white"
                    >
                      <XCircle className="w-4 h-4 mr-1" />
                      Injoignable
                    </Button>
                    <Button
                      size="sm"
                      variant={order.status === "rejected" ? "default" : "outline"}
                      onClick={() => handleUpdateStatus(order.id, "rejected")}
                      className="flex-1 min-w-[120px] hover:bg-red-500 hover:text-white"
                    >
                      <XCircle className="w-4 h-4 mr-1" />
                      Rejeté
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredOrders.length === 0 && (
          <Card className="border-dashed">
            <CardContent className="text-center py-16">
              <Truck className="w-20 h-20 mx-auto text-muted-foreground/50 mb-4" />
              <h3 className="text-xl font-semibold mb-2">
                {searchQuery || statusFilter !== "all" 
                  ? "Aucune livraison trouvée" 
                  : "Aucune livraison pour le moment"}
              </h3>
              <p className="text-muted-foreground">
                {searchQuery || statusFilter !== "all"
                  ? "Essayez de modifier vos filtres"
                  : "Les livraisons apparaîtront ici dès réception des commandes"}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
}
