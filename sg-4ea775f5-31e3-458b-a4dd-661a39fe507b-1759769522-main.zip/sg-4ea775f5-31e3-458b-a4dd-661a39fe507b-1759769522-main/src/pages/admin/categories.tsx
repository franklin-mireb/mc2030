
import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Tag, ArrowLeft } from "lucide-react";
import Link from "next/link";

interface Category {
  id: string;
  label: string;
}

const CATEGORIES_KEY = "mireb_categories";

export default function AdminCategoriesPage() {
  const router = useRouter();
  const [categories, setCategories] = useState<Category[]>([]);
  const [newCategory, setNewCategory] = useState("");

  useEffect(() => {
    const user = localStorage.getItem("user");
    if (!user) {
      router.push("/admin/login");
      return;
    }

    loadCategories();
  }, [router]);

  const loadCategories = () => {
    if (typeof window === "undefined") return;
    
    try {
      const stored = localStorage.getItem(CATEGORIES_KEY);
      if (stored) {
        setCategories(JSON.parse(stored));
      } else {
        const defaultCategories = [
          { id: "Électronique", label: "Électronique" },
          { id: "Mode", label: "Mode" },
          { id: "Maison", label: "Maison" },
          { id: "Beauté", label: "Beauté" },
          { id: "Sports", label: "Sports" },
          { id: "Jouets", label: "Jouets" },
        ];
        setCategories(defaultCategories);
        localStorage.setItem(CATEGORIES_KEY, JSON.stringify(defaultCategories));
      }
    } catch (error) {
      console.error("Error loading categories:", error);
    }
  };

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newCategory.trim()) return;
    
    const categoryExists = categories.some(
      (cat) => cat.id.toLowerCase() === newCategory.trim().toLowerCase()
    );
    
    if (categoryExists) {
      alert("Cette catégorie existe déjà!");
      return;
    }

    const newCat: Category = {
      id: newCategory.trim(),
      label: newCategory.trim(),
    };

    const updatedCategories = [...categories, newCat];
    setCategories(updatedCategories);
    localStorage.setItem(CATEGORIES_KEY, JSON.stringify(updatedCategories));
    setNewCategory("");
  };

  const handleDeleteCategory = (categoryId: string) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer cette catégorie?")) return;

    const updatedCategories = categories.filter((cat) => cat.id !== categoryId);
    setCategories(updatedCategories);
    localStorage.setItem(CATEGORIES_KEY, JSON.stringify(updatedCategories));
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        <div className="mb-6">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour au tableau de bord
            </Button>
          </Link>
        </div>

        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-2">
            Gestion des catégories
          </h1>
          <p className="text-muted-foreground flex items-center gap-2">
            <Tag className="w-4 h-4" />
            Ajoutez ou supprimez des catégories de produits
          </p>
        </div>

        <Card className="mb-8 border-2 border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5" />
              Ajouter une nouvelle catégorie
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddCategory} className="flex gap-3">
              <Input
                placeholder="Nom de la catégorie (ex: Informatique)"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                className="flex-1"
              />
              <Button type="submit" disabled={!newCategory.trim()}>
                <Plus className="w-4 h-4 mr-2" />
                Ajouter
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Tag className="w-5 h-5" />
                Catégories existantes
              </span>
              <Badge variant="secondary">{categories.length} catégories</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {categories.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Tag className="w-16 h-16 mx-auto mb-4 opacity-20" />
                <p>Aucune catégorie disponible</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-3">
                {categories.map((category) => (
                  <Card key={category.id} className="border-2 hover:border-primary/50 transition-colors">
                    <CardContent className="p-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="bg-primary/10 p-2 rounded-lg">
                          <Tag className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-semibold text-lg">{category.label}</p>
                          <p className="text-xs text-muted-foreground">ID: {category.id}</p>
                        </div>
                      </div>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDeleteCategory(category.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="mt-6 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
          <CardContent className="p-6">
            <h3 className="font-semibold mb-2 flex items-center gap-2">
              <Tag className="w-5 h-5 text-blue-600" />
              Note importante
            </h3>
            <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
              <li>Les catégories sont utilisées pour organiser vos produits</li>
              <li>Assurez-vous d'utiliser des noms clairs et compréhensibles</li>
              <li>Les catégories supprimées n'affecteront pas les produits existants</li>
              <li>Les produits garderont leur catégorie même si elle est supprimée de la liste</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
