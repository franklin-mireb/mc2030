import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Order } from "@/types";
import { getOrders, updateOrderStatus } from "@/lib/localStorage";
import { 
  Package, 
  Phone, 
  MessageCircle, 
  Calendar,
  Search,
  Filter,
  MapPin,
  User,
  DollarSign,
  CheckCircle2,
  XCircle,
  Clock,
  AlertCircle,
  TrendingUp
} from "lucide-react";

const statusConfig = {
  new: { label: "Nouveau", color: "bg-blue-500", icon: AlertCircle, textColor: "text-blue-600" },
  postponed: { label: "Reporté", color: "bg-yellow-500", icon: Clock, textColor: "text-yellow-600" },
  delivered: { label: "Livré", color: "bg-green-500", icon: CheckCircle2, textColor: "text-green-600" },
  unreachable: { label: "Injoignable", color: "bg-orange-500", icon: XCircle, textColor: "text-orange-600" },
  rejected: { label: "Rejeté", color: "bg-red-500", icon: XCircle, textColor: "text-red-600" },
};

export default function AdminOrdersPage() {
  const router = useRouter();
  const [orders, setOrders] = useState<Order[]>([]);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [stats, setStats] = useState({
    total: 0,
    new: 0,
    postponed: 0,
    delivered: 0,
    unreachable: 0,
    rejected: 0,
    totalRevenue: 0
  });

  useEffect(() => {
    const user = localStorage.getItem("user");
    if (!user) {
      router.push("/admin/login");
      return;
    }

    loadOrders();
  }, [router]);

  const loadOrders = () => {
    const allOrders = getOrders();
    const sortedOrders = allOrders.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    
    setOrders(sortedOrders);
    
    const newStats = {
      total: allOrders.length,
      new: allOrders.filter(o => o.status === "new").length,
      postponed: allOrders.filter(o => o.status === "postponed").length,
      delivered: allOrders.filter(o => o.status === "delivered").length,
      unreachable: allOrders.filter(o => o.status === "unreachable").length,
      rejected: allOrders.filter(o => o.status === "rejected").length,
      totalRevenue: allOrders
        .filter(o => o.status === "delivered")
        .reduce((sum, order) => sum + order.totalPrice, 0)
    };
    
    setStats(newStats);
  };

  const handleStatusChange = (orderId: string, newStatus: string) => {
    updateOrderStatus(orderId, newStatus as Order["status"]);
    loadOrders();
  };

  const handleCall = (phone: string) => {
    window.location.href = `tel:${phone}`;
  };

  const handleWhatsApp = (phone: string, customerName: string, productTitle: string) => {
    const message = encodeURIComponent(
      `Bonjour ${customerName}, concernant votre commande de ${productTitle}...`
    );
    const cleanPhone = phone.replace(/\D/g, "");
    window.open(`https://wa.me/${cleanPhone}?text=${message}`, "_blank");
  };

  const filteredOrders = orders.filter((order) => {
    const matchesStatus = filterStatus === "all" || order.status === filterStatus;
    const matchesSearch = searchQuery === "" || 
      order.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customerPhone.includes(searchQuery) ||
      order.productTitle.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6">
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-2">
            Gestion des commandes
          </h1>
          <p className="text-muted-foreground flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Suivez et gérez toutes vos commandes
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
          <Card className="border-2 hover:border-primary transition-colors cursor-pointer" onClick={() => setFilterStatus("all")}>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-primary">{stats.total}</div>
              <p className="text-xs text-muted-foreground mt-1">Total</p>
            </CardContent>
          </Card>
          
          <Card className="border-2 hover:border-blue-500 transition-colors cursor-pointer" onClick={() => setFilterStatus("new")}>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-blue-600">{stats.new}</div>
              <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                Nouveau
              </p>
            </CardContent>
          </Card>
          
          <Card className="border-2 hover:border-yellow-500 transition-colors cursor-pointer" onClick={() => setFilterStatus("postponed")}>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-yellow-600">{stats.postponed}</div>
              <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                <Clock className="w-3 h-3" />
                Reporté
              </p>
            </CardContent>
          </Card>
          
          <Card className="border-2 hover:border-green-500 transition-colors cursor-pointer" onClick={() => setFilterStatus("delivered")}>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-green-600">{stats.delivered}</div>
              <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                Livré
              </p>
            </CardContent>
          </Card>
          
          <Card className="border-2 hover:border-orange-500 transition-colors cursor-pointer" onClick={() => setFilterStatus("unreachable")}>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-orange-600">{stats.unreachable}</div>
              <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                <XCircle className="w-3 h-3" />
                Injoignable
              </p>
            </CardContent>
          </Card>
          
          <Card className="border-2 hover:border-red-500 transition-colors cursor-pointer" onClick={() => setFilterStatus("rejected")}>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-red-600">{stats.rejected}</div>
              <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                <XCircle className="w-3 h-3" />
                Rejeté
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-6 bg-gradient-to-r from-green-500/10 to-green-600/5 border-green-200 dark:border-green-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Revenus totaux (Livrés)</p>
                <div className="text-4xl font-bold text-green-600 dark:text-green-400">
                  {stats.totalRevenue.toLocaleString()} F CFA
                </div>
              </div>
              <DollarSign className="w-16 h-16 text-green-500/20" />
            </div>
          </CardContent>
        </Card>

        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Rechercher par nom, téléphone ou produit..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-full md:w-[200px]">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Filtrer par statut" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous les statuts</SelectItem>
              <SelectItem value="new">Nouveau</SelectItem>
              <SelectItem value="postponed">Reporté</SelectItem>
              <SelectItem value="delivered">Livré</SelectItem>
              <SelectItem value="unreachable">Injoignable</SelectItem>
              <SelectItem value="rejected">Rejeté</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-4">
          {filteredOrders.map((order) => {
            const status = statusConfig[order.status];
            const StatusIcon = status.icon;
            
            return (
              <Card key={order.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row gap-6">
                    <div className="flex-1 space-y-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <h3 className="font-bold text-xl mb-2 flex items-center gap-2">
                            <Package className="w-5 h-5 text-primary" />
                            {order.productTitle}
                          </h3>
                          <Badge className={`${status.color} text-white flex items-center gap-1 w-fit`}>
                            <StatusIcon className="w-3 h-3" />
                            {status.label}
                          </Badge>
                        </div>
                        <div className="text-right">
                          <div className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                            {order.totalPrice.toLocaleString()} F
                          </div>
                          <div className="text-sm text-muted-foreground mt-1">
                            Quantité: {order.quantity}
                          </div>
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-sm">
                            <User className="w-4 h-4 text-muted-foreground" />
                            <span className="text-muted-foreground">Client:</span>
                            <span className="font-semibold">{order.customerName}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Phone className="w-4 h-4 text-muted-foreground" />
                            <span className="text-muted-foreground">Téléphone:</span>
                            <span className="font-semibold">{order.customerPhone}</span>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-sm">
                            <MapPin className="w-4 h-4 text-muted-foreground" />
                            <span className="text-muted-foreground">Ville:</span>
                            <span className="font-semibold">{order.customerCity}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Calendar className="w-4 h-4 text-muted-foreground" />
                            <span className="text-muted-foreground">Date:</span>
                            <span className="font-semibold">
                              {new Date(order.createdAt).toLocaleDateString("fr-FR", {
                                day: "2-digit",
                                month: "long",
                                year: "numeric"
                              })}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="bg-muted/50 p-3 rounded-lg">
                        <p className="text-sm text-muted-foreground mb-1 flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          Adresse complète
                        </p>
                        <p className="text-sm font-medium">{order.customerAddress}</p>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleCall(order.customerPhone)}
                          className="bg-blue-500 hover:bg-blue-600"
                        >
                          <Phone className="w-4 h-4 mr-2" />
                          Appeler le client
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => 
                            handleWhatsApp(
                              order.customerPhone,
                              order.customerName,
                              order.productTitle
                            )
                          }
                          className="bg-green-500 hover:bg-green-600"
                        >
                          <MessageCircle className="w-4 h-4 mr-2" />
                          Envoyer WhatsApp
                        </Button>
                      </div>
                    </div>

                    <div className="lg:w-[250px] space-y-3">
                      <div className="bg-muted/30 p-4 rounded-lg">
                        <label className="block text-sm font-semibold mb-3 text-center">
                          Modifier le statut
                        </label>
                        <Select
                          value={order.status}
                          onValueChange={(value) => handleStatusChange(order.id, value)}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="new">
                              <div className="flex items-center gap-2">
                                <AlertCircle className="w-4 h-4" />
                                Nouveau
                              </div>
                            </SelectItem>
                            <SelectItem value="postponed">
                              <div className="flex items-center gap-2">
                                <Clock className="w-4 h-4" />
                                Reporté
                              </div>
                            </SelectItem>
                            <SelectItem value="delivered">
                              <div className="flex items-center gap-2">
                                <CheckCircle2 className="w-4 h-4" />
                                Livré
                              </div>
                            </SelectItem>
                            <SelectItem value="unreachable">
                              <div className="flex items-center gap-2">
                                <XCircle className="w-4 h-4" />
                                Injoignable
                              </div>
                            </SelectItem>
                            <SelectItem value="rejected">
                              <div className="flex items-center gap-2">
                                <XCircle className="w-4 h-4" />
                                Rejeté
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredOrders.length === 0 && (
          <Card className="border-dashed">
            <CardContent className="text-center py-16">
              <Package className="w-20 h-20 mx-auto text-muted-foreground/50 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Aucune commande trouvée</h3>
              <p className="text-muted-foreground">
                {searchQuery ? "Essayez une autre recherche" : "Les commandes apparaîtront ici"}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
}
