import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { getOrders } from "@/lib/localStorage";
import { 
  Phone, 
  MessageCircle, 
  MapPin, 
  ShoppingCart, 
  Users,
  TrendingUp,
  Calendar,
  Search,
  Award,
  DollarSign
} from "lucide-react";

interface CustomerData {
  phone: string;
  name: string;
  city: string;
  address: string;
  orderCount: number;
  totalSpent: number;
  lastOrderDate: string;
}

export default function AdminCustomersPage() {
  const router = useRouter();
  const [customers, setCustomers] = useState<CustomerData[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [stats, setStats] = useState({
    totalCustomers: 0,
    totalRevenue: 0,
    averageOrderValue: 0,
    topCustomer: null as CustomerData | null
  });

  useEffect(() => {
    const user = localStorage.getItem("user");
    if (!user) {
      router.push("/admin/login");
      return;
    }

    loadCustomers();
  }, [router]);

  const loadCustomers = () => {
    const orders = getOrders();
    
    const customerMap = new Map<string, CustomerData>();
    
    orders.forEach((order) => {
      const existing = customerMap.get(order.customerPhone);
      
      if (existing) {
        existing.orderCount += 1;
        existing.totalSpent += order.totalPrice;
        if (new Date(order.createdAt) > new Date(existing.lastOrderDate)) {
          existing.lastOrderDate = order.createdAt;
        }
      } else {
        customerMap.set(order.customerPhone, {
          phone: order.customerPhone,
          name: order.customerName,
          city: order.customerCity,
          address: order.customerAddress,
          orderCount: 1,
          totalSpent: order.totalPrice,
          lastOrderDate: order.createdAt,
        });
      }
    });

    const customerArray = Array.from(customerMap.values()).sort(
      (a, b) => b.totalSpent - a.totalSpent
    );
    
    setCustomers(customerArray);

    const totalRevenue = customerArray.reduce((sum, c) => sum + c.totalSpent, 0);
    const totalOrders = customerArray.reduce((sum, c) => sum + c.orderCount, 0);

    setStats({
      totalCustomers: customerArray.length,
      totalRevenue,
      averageOrderValue: totalOrders > 0 ? totalRevenue / totalOrders : 0,
      topCustomer: customerArray[0] || null
    });
  };

  const handleCall = (phone: string) => {
    window.location.href = `tel:${phone}`;
  };

  const handleWhatsApp = (phone: string, name: string) => {
    const message = encodeURIComponent(`Bonjour ${name}, merci pour votre confiance à Mireb Commercial!`);
    const cleanPhone = phone.replace(/\D/g, "");
    window.open(`https://wa.me/${cleanPhone}?text=${message}`, "_blank");
  };

  const filteredCustomers = customers.filter((customer) =>
    customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    customer.phone.includes(searchQuery) ||
    customer.city.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6">
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-2">
            Gestion des clients
          </h1>
          <p className="text-muted-foreground flex items-center gap-2">
            <Users className="w-4 h-4" />
            Gérez vos relations clients et communiquez facilement
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="border-2 hover:border-primary transition-colors">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <Users className="w-8 h-8 text-primary/60" />
                <Badge variant="secondary">{stats.totalCustomers}</Badge>
              </div>
              <h3 className="text-2xl font-bold text-primary">{stats.totalCustomers}</h3>
              <p className="text-sm text-muted-foreground">Clients totaux</p>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-green-500 transition-colors">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <DollarSign className="w-8 h-8 text-green-500/60" />
                <TrendingUp className="w-5 h-5 text-green-500" />
              </div>
              <h3 className="text-2xl font-bold text-green-600">
                {stats.totalRevenue.toLocaleString()}
              </h3>
              <p className="text-sm text-muted-foreground">Revenu total (F CFA)</p>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-blue-500 transition-colors">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <ShoppingCart className="w-8 h-8 text-blue-500/60" />
                <Badge variant="outline" className="text-blue-600">Moy.</Badge>
              </div>
              <h3 className="text-2xl font-bold text-blue-600">
                {stats.averageOrderValue.toLocaleString()}
              </h3>
              <p className="text-sm text-muted-foreground">Valeur moy. (F CFA)</p>
            </CardContent>
          </Card>

          {stats.topCustomer && (
            <Card className="border-2 border-yellow-500/50 bg-gradient-to-br from-yellow-500/5 to-yellow-600/5">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Award className="w-8 h-8 text-yellow-500" />
                  <Badge className="bg-yellow-500 text-white">Top</Badge>
                </div>
                <h3 className="text-lg font-bold text-yellow-600 truncate">
                  {stats.topCustomer.name}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {stats.topCustomer.totalSpent.toLocaleString()} F CFA
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Rechercher par nom, téléphone ou ville..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCustomers.map((customer, index) => (
            <Card 
              key={customer.phone} 
              className="hover:shadow-lg transition-all hover:scale-[1.02] border-2 hover:border-primary/50"
            >
              <CardHeader>
                <CardTitle className="text-lg flex items-center justify-between gap-2">
                  <span className="truncate flex items-center gap-2">
                    {index < 3 && (
                      <Award className="w-5 h-5 text-yellow-500 flex-shrink-0" />
                    )}
                    {customer.name}
                  </span>
                  <Badge variant="secondary" className="flex-shrink-0">
                    {customer.orderCount} {customer.orderCount === 1 ? "commande" : "commandes"}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 mb-4">
                  <div className="flex items-start gap-2">
                    <Phone className="w-4 h-4 mt-1 text-muted-foreground flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm text-muted-foreground">Téléphone</p>
                      <p className="font-medium truncate">{customer.phone}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 mt-1 text-muted-foreground flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm text-muted-foreground">Ville</p>
                      <p className="font-medium truncate">{customer.city}</p>
                    </div>
                  </div>

                  <div className="bg-primary/5 p-3 rounded-lg">
                    <div className="flex items-start gap-2">
                      <ShoppingCart className="w-4 h-4 mt-1 text-primary flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm text-muted-foreground">Total dépensé</p>
                        <p className="font-bold text-xl text-primary">
                          {customer.totalSpent.toLocaleString()} F
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-muted-foreground">Dernière commande</p>
                      <p className="font-medium truncate">
                        {new Date(customer.lastOrderDate).toLocaleDateString("fr-FR", {
                          day: "2-digit",
                          month: "long",
                          year: "numeric"
                        })}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 hover:bg-blue-500 hover:text-white hover:border-blue-500"
                    onClick={() => handleCall(customer.phone)}
                  >
                    <Phone className="w-4 h-4 mr-1" />
                    Appeler
                  </Button>
                  <Button
                    size="sm"
                    className="flex-1 bg-green-500 hover:bg-green-600"
                    onClick={() => handleWhatsApp(customer.phone, customer.name)}
                  >
                    <MessageCircle className="w-4 h-4 mr-1" />
                    WhatsApp
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredCustomers.length === 0 && (
          <Card className="border-dashed">
            <CardContent className="text-center py-16">
              <Users className="w-20 h-20 mx-auto text-muted-foreground/50 mb-4" />
              <h3 className="text-xl font-semibold mb-2">
                {searchQuery ? "Aucun client trouvé" : "Aucun client pour le moment"}
              </h3>
              <p className="text-muted-foreground">
                {searchQuery 
                  ? "Essayez une autre recherche" 
                  : "Les clients apparaîtront ici après leurs premières commandes"}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
}
