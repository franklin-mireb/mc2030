import { useState, useEffect } from "react";
import { useRouter } from "next/router";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, Package, TrendingUp, Star, Flame, Sparkles, ChevronLeft, ChevronRight, Phone } from "lucide-react";
import { Product, Order } from "@/types";
import { getProducts, saveOrder } from "@/lib/localStorage";
import { ProductCard } from "@/components/products/ProductCard";
import { sendWhatsAppMessage } from "@/lib/supabase";

const statusConfig = {
  "Vente chaude": { icon: Flame, color: "bg-red-500 text-white" },
  "Meilleure vente": { icon: TrendingUp, color: "bg-blue-500 text-white" },
  "Vedette": { icon: Star, color: "bg-yellow-500 text-white" },
  "Nouveauté": { icon: Sparkles, color: "bg-green-500 text-white" },
};

export default function ProductDetailPage() {
  const router = useRouter();
  const { id } = router.query;
  const [product, setProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  const [formData, setFormData] = useState({
    fullName: "",
    address: "",
    phone: "",
    city: "",
    notes: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (id) {
      const products = getProducts();
      const foundProduct = products.find((p) => p.id === id);
      setProduct(foundProduct || null);

      if (foundProduct) {
        const related = products
          .filter((p) => p.category === foundProduct.category && p.id !== foundProduct.id)
          .slice(0, 4);
        setRelatedProducts(related);
      }
    }
  }, [id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!product) return;

    setIsSubmitting(true);

    try {
      const order: Order = {
        id: `order-${Date.now()}`,
        productId: product.id,
        productTitle: product.title,
        productImage: product.images[0],
        quantity,
        totalPrice: product.price * quantity,
        customerName: formData.fullName,
        customerPhone: formData.phone,
        customerAddress: formData.address,
        customerCity: formData.city,
        notes: formData.notes,
        status: "new",
        createdAt: new Date().toISOString(),
      };

      saveOrder(order);

      const message = `Nouvelle commande:\n\nProduit: ${product.title}\nQuantité: ${quantity}\nTotal: $${order.totalPrice}\n\nClient:\n${formData.fullName}\n${formData.phone}\n${formData.address}\n${formData.city}\n\nNotes: ${formData.notes || "Aucune"}`;

      sendWhatsAppMessage(message);

      alert("Commande envoyée avec succès ! Nous vous contacterons bientôt.");

      setFormData({
        fullName: "",
        address: "",
        phone: "",
        city: "",
        notes: "",
      });
      setQuantity(1);
    } catch (error) {
      console.error("Error submitting order:", error);
      alert("Erreur lors de l'envoi de la commande. Veuillez réessayer.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const nextImage = () => {
    if (product) {
      setSelectedImage((prev) => (prev + 1) % product.images.length);
    }
  };

  const prevImage = () => {
    if (product) {
      setSelectedImage((prev) => (prev - 1 + product.images.length) % product.images.length);
    }
  };

  if (!product) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <p className="text-center text-gray-500">Chargement...</p>
        </div>
      </Layout>
    );
  }

  const statusInfo = statusConfig[product.status as keyof typeof statusConfig];
  const StatusIcon = statusInfo?.icon;

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            <div className="space-y-4">
              <div className="relative aspect-square rounded-2xl overflow-hidden bg-white dark:bg-gray-800 shadow-2xl group">
                <img
                  src={product.images[selectedImage]}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
                {product.images.length > 1 && (
                  <>
                    <button
                      onClick={prevImage}
                      className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 dark:bg-gray-800/90 p-3 rounded-full shadow-lg hover:bg-white dark:hover:bg-gray-700 transition-all"
                      aria-label="Image précédente"
                    >
                      <ChevronLeft className="w-6 h-6" />
                    </button>
                    <button
                      onClick={nextImage}
                      className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 dark:bg-gray-800/90 p-3 rounded-full shadow-lg hover:bg-white dark:hover:bg-gray-700 transition-all"
                      aria-label="Image suivante"
                    >
                      <ChevronRight className="w-6 h-6" />
                    </button>
                  </>
                )}
                {statusInfo && (
                  <Badge className={`absolute top-4 left-4 ${statusInfo.color} border-0 shadow-lg flex items-center gap-2 px-4 py-2`}>
                    {StatusIcon && <StatusIcon className="w-4 h-4" />}
                    <span className="font-semibold">{product.status}</span>
                  </Badge>
                )}
              </div>

              {product.images.length > 1 && (
                <div className="grid grid-cols-5 gap-3">
                  {product.images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedImage(idx)}
                      className={`aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                        selectedImage === idx
                          ? "border-orange-500 shadow-lg scale-105"
                          : "border-gray-200 dark:border-gray-600 hover:border-orange-300"
                      }`}
                    >
                      <img
                        src={img}
                        alt={`${product.title} ${idx + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-6">
              <div>
                <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-orange-600 to-orange-500 bg-clip-text text-transparent">
                  {product.title}
                </h1>
                <div className="flex items-baseline gap-3 mb-4">
                  <span className="text-5xl font-bold text-orange-600">${product.price}</span>
                  <span className="text-gray-500 dark:text-gray-400">par unité</span>
                </div>
                <div className="flex items-center gap-2 mb-6">
                  <Package className="w-5 h-5 text-gray-500" />
                  <span className="text-gray-600 dark:text-gray-300">
                    MOQ: <span className="font-semibold text-orange-600">{product.moq} unités minimum</span>
                  </span>
                </div>
              </div>

              <Card className="border-2 border-orange-200 dark:border-orange-800 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20">
                  <CardTitle className="flex items-center gap-2 text-orange-800 dark:text-orange-200">
                    <ShoppingCart className="w-5 h-5" />
                    Commander maintenant
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <Label htmlFor="quantity">Quantité</Label>
                      <Input
                        id="quantity"
                        type="number"
                        min={product.moq}
                        value={quantity}
                        onChange={(e) => setQuantity(Math.max(product.moq, parseInt(e.target.value) || product.moq))}
                        className="text-lg font-semibold"
                        required
                      />
                      <p className="text-sm text-gray-500 mt-1">
                        Total: <span className="font-bold text-orange-600">${(product.price * quantity).toFixed(2)}</span>
                      </p>
                    </div>

                    <div>
                      <Label htmlFor="fullName">Nom complet *</Label>
                      <Input
                        id="fullName"
                        value={formData.fullName}
                        onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="phone">Téléphone *</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="city">Ville *</Label>
                      <Input
                        id="city"
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="address">Adresse complète *</Label>
                      <Textarea
                        id="address"
                        value={formData.address}
                        onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                        rows={3}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="notes">Notes (optionnel)</Label>
                      <Textarea
                        id="notes"
                        value={formData.notes}
                        onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                        rows={3}
                        placeholder="Informations supplémentaires..."
                      />
                    </div>

                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white text-lg py-6 shadow-lg hover:shadow-xl transition-all duration-300 font-bold animate-pulse hover:animate-none"
                    >
                      <ShoppingCart className="w-5 h-5 mr-2" />
                      {isSubmitting ? "Envoi en cours..." : "Commander"}
                    </Button>

                    <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
                      <Phone className="w-4 h-4" />
                      <span>Commande via WhatsApp: +243842267252</span>
                    </div>
                  </form>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Description du produit</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed whitespace-pre-line">
                    {product.description}
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {relatedProducts.length > 0 && (
            <div className="mt-16">
              <h2 className="text-3xl font-bold mb-8 text-center bg-gradient-to-r from-orange-600 to-orange-500 bg-clip-text text-transparent">
                Produits similaires
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {relatedProducts.map((relatedProduct) => (
                  <ProductCard key={relatedProduct.id} product={relatedProduct} />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
