import { useState, useEffect } from "react";
import { Layout } from "@/components/layout/Layout";
import { ProductCard } from "@/components/products/ProductCard";
import { CategoryFilter } from "@/components/products/CategoryFilter";
import { StatusFilter } from "@/components/products/StatusFilter";
import { Product } from "@/types";
import { mockProducts } from "@/lib/mockData";
import { getProducts } from "@/lib/localStorage";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Flame, 
  Trophy, 
  Star, 
  Sparkles, 
  TrendingUp, 
  ShoppingBag,
  ArrowRight,
  Zap,
  Gift,
  Package
} from "lucide-react";

export default function HomePage() {
  const [mounted, setMounted] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<string | null>(null);

  useEffect(() => {
    setMounted(true);
    const storedProducts = getProducts();
    if (storedProducts.length > 0) {
      setProducts(storedProducts);
    } else {
      setProducts(mockProducts);
    }
  }, []);

  if (!mounted) {
    return (
      <Layout>
        <div className="bg-gradient-to-b from-orange-50 via-white to-gray-50 dark:from-gray-900 dark:via-background dark:to-gray-950">
          <div className="container mx-auto px-4 py-6">
            <div className="animate-pulse space-y-8">
              <div className="h-64 bg-gray-200 dark:bg-gray-800 rounded-lg"></div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="h-80 bg-gray-200 dark:bg-gray-800 rounded-lg"></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  const filteredProducts = products.filter((product) => {
    const matchesCategory = !selectedCategory || selectedCategory === "all" || product.category === selectedCategory;
    const matchesStatus =
      !selectedStatus ||
      selectedStatus === "all" ||
      (selectedStatus === "Vente chaude" && product.status === "Vente chaude") ||
      (selectedStatus === "Meilleure vente" && product.status === "Meilleure vente") ||
      (selectedStatus === "Vedette" && product.status === "Vedette") ||
      (selectedStatus === "Nouveauté" && product.status === "Nouveauté");
    return matchesCategory && matchesStatus;
  });

  const hotDeals = products.filter((p) => p.status === "Vente chaude").slice(0, 6);
  const bestsellers = products.filter((p) => p.status === "Meilleure vente").slice(0, 6);
  const featured = products.filter((p) => p.status === "Vedette").slice(0, 6);
  const newArrivals = products.filter((p) => p.status === "Nouveauté").slice(0, 6);

  const specialCategories = [
    { 
      icon: Flame, 
      title: "Ventes Chaudes", 
      emoji: "🔥", 
      color: "from-red-500 to-orange-500",
      products: hotDeals,
      badge: "HOT"
    },
    { 
      icon: Trophy, 
      title: "Meilleures Ventes", 
      emoji: "🏆", 
      color: "from-yellow-500 to-amber-500",
      products: bestsellers,
      badge: "TOP"
    },
    { 
      icon: Star, 
      title: "Produits Vedettes", 
      emoji: "⭐", 
      color: "from-purple-500 to-pink-500",
      products: featured,
      badge: "STAR"
    },
    { 
      icon: Sparkles, 
      title: "Nouveautés", 
      emoji: "🆕", 
      color: "from-blue-500 to-cyan-500",
      products: newArrivals,
      badge: "NEW"
    }
  ];

  return (
    <Layout>
      <div className="bg-gradient-to-b from-orange-50 via-white to-gray-50 dark:from-gray-900 dark:via-background dark:to-gray-950">
        <div className="container mx-auto px-4 py-6 space-y-8">
          <Card className="relative bg-gradient-to-br from-orange-500 via-red-500 to-pink-600 text-white p-8 md:p-12 overflow-hidden border-0 shadow-2xl">
            <div className="absolute inset-0 bg-black/10"></div>
            <div className="absolute -right-20 -top-20 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
            <div className="absolute -left-20 -bottom-20 w-80 h-80 bg-white/10 rounded-full blur-3xl"></div>
            
            <div className="relative z-10 space-y-4">
              <div className="flex items-center gap-3">
                <ShoppingBag className="w-8 h-8 animate-bounce" />
                <Badge className="bg-white/30 text-white border-white/50 text-sm font-semibold px-3 py-1">
                  Plateforme E-commerce
                </Badge>
              </div>
              
              <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4">
                Mireb Commercial
              </h1>
              
              <p className="text-xl md:text-2xl text-white/95 font-medium max-w-2xl">
                Découvrez des milliers de produits de qualité aux prix les plus compétitifs du marché
              </p>
              
              <div className="flex flex-wrap gap-4 pt-4">
                <Button size="lg" className="bg-white text-orange-600 hover:bg-white/90 font-bold shadow-lg hover:shadow-xl transition-all">
                  <Gift className="w-5 h-5 mr-2" />
                  Voir les offres
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <Button size="lg" variant="outline" className="border-white/50 text-white hover:bg-white/20 font-bold">
                  <Package className="w-5 h-5 mr-2" />
                  Parcourir le catalogue
                </Button>
              </div>
              
              <div className="flex flex-wrap gap-6 pt-6 text-sm md:text-base">
                <div className="flex items-center gap-2">
                  <Zap className="w-5 h-5" />
                  <span className="font-semibold">Livraison rapide</span>
                </div>
                <div className="flex items-center gap-2">
                  <Trophy className="w-5 h-5" />
                  <span className="font-semibold">Produits certifiés</span>
                </div>
                <div className="flex items-center gap-2">
                  <Star className="w-5 h-5" />
                  <span className="font-semibold">Service client 24/7</span>
                </div>
              </div>
            </div>
          </Card>

          {specialCategories.map((category) => {
            if (category.products.length === 0) return null;
            
            const Icon = category.icon;
            
            return (
              <div key={category.title} className="space-y-4">
                <Card className={`bg-gradient-to-r ${category.color} p-4 border-0 shadow-lg`}>
                  <div className="flex items-center justify-between text-white">
                    <div className="flex items-center gap-3">
                      <div className="bg-white/20 p-2 rounded-lg backdrop-blur-sm">
                        <Icon className="w-6 h-6" />
                      </div>
                      <div>
                        <h2 className="text-2xl md:text-3xl font-bold flex items-center gap-2">
                          {category.title}
                          <span className="text-3xl">{category.emoji}</span>
                        </h2>
                        <p className="text-white/90 text-sm">
                          {category.products.length} produits disponibles
                        </p>
                      </div>
                    </div>
                    <Badge className="bg-white/30 text-white border-white/50 font-bold px-3 py-1 hidden md:block">
                      {category.badge}
                    </Badge>
                  </div>
                </Card>
                
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
                  {category.products.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              </div>
            );
          })}

          <div className="pt-8">
            <Card className="bg-gradient-to-r from-primary/10 to-accent/10 p-6 border-2 border-primary/20 mb-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-primary/20 p-3 rounded-full">
                  <TrendingUp className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl md:text-3xl font-bold">Tous les Produits</h2>
                  <p className="text-muted-foreground">
                    Explorez notre catalogue complet
                  </p>
                </div>
              </div>
            </Card>

            <div className="space-y-4">
              <CategoryFilter
                selectedCategory={selectedCategory}
                onSelectCategory={setSelectedCategory}
              />

              <StatusFilter
                selectedStatus={selectedStatus}
                onSelectStatus={setSelectedStatus}
              />

              <div className="flex items-center justify-between">
                <p className="text-muted-foreground font-medium">
                  <span className="text-primary font-bold text-lg">{filteredProducts.length}</span> produit(s) disponible(s)
                </p>
                {(selectedCategory || selectedStatus) && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setSelectedCategory(null);
                      setSelectedStatus(null);
                    }}
                  >
                    Réinitialiser les filtres
                  </Button>
                )}
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>

              {filteredProducts.length === 0 && (
                <Card className="border-dashed border-2">
                  <div className="text-center py-16">
                    <Package className="w-20 h-20 mx-auto text-muted-foreground/50 mb-4" />
                    <h3 className="text-xl font-semibold mb-2">Aucun produit trouvé</h3>
                    <p className="text-muted-foreground mb-4">
                      Essayez de modifier vos filtres ou parcourez nos catégories spéciales
                    </p>
                    <Button 
                      onClick={() => {
                        setSelectedCategory(null);
                        setSelectedStatus(null);
                      }}
                    >
                      Voir tous les produits
                    </Button>
                  </div>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
