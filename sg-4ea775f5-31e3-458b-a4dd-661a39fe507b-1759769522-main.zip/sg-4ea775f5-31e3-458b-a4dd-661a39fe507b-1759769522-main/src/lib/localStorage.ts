import { Product, Order, Customer, Delivery } from "@/types";

const STORAGE_KEYS = {
  PRODUCTS: "mireb_products",
  ORDERS: "mireb_orders",
  CUSTOMERS: "mireb_customers",
  DELIVERIES: "mireb_deliveries",
};

export const getProducts = (): Product[] => {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error("Error getting products:", error);
    return [];
  }
};

export const saveProduct = (product: Product): void => {
  if (typeof window === "undefined") return;
  try {
    const products = getProducts();
    const existingIndex = products.findIndex((p) => p.id === product.id);
    
    if (existingIndex >= 0) {
      products[existingIndex] = product;
    } else {
      products.push(product);
    }
    
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
  } catch (error) {
    console.error("Error saving product:", error);
  }
};

export const deleteProduct = (id: string): void => {
  if (typeof window === "undefined") return;
  try {
    const products = getProducts().filter((p) => p.id !== id);
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
  } catch (error) {
    console.error("Error deleting product:", error);
  }
};

export const getOrders = (): Order[] => {
  if (typeof window === "undefined") return [];
  try {
    const data = localStorage.getItem(STORAGE_KEYS.ORDERS);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error("Error getting orders:", error);
    return [];
  }
};

export const saveOrder = (order: Order): void => {
  if (typeof window === "undefined") return;
  try {
    const orders = getOrders();
    orders.push(order);
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  } catch (error) {
    console.error("Error saving order:", error);
  }
};

export const updateOrderStatus = (orderId: string, status: Order["status"]): void => {
  if (typeof window === "undefined") return;
  try {
    const orders = getOrders();
    const orderIndex = orders.findIndex((o) => o.id === orderId);
    if (orderIndex >= 0) {
      orders[orderIndex].status = status;
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
    }
  } catch (error) {
    console.error("Error updating order status:", error);
  }
};