import { Product } from "@/types";

export const mockProducts: Product[] = [
  {
    id: "1",
    title: "Smartphone Android Haute Performance",
    description: "Smartphone Android dernière génération avec écran AMOLED 6.5 pouces, processeur octa-core, 8GB RAM, 128GB stockage. Idéal pour la revente en gros.",
    price: 299.99,
    moq: 10,
    category: "Électronique",
    status: "Vente chaude",
    images: [
      "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800",
      "https://images.unsplash.com/photo-1592286927505-c0d0eb5c4ec1?w=800",
      "https://images.unsplash.com/photo-1565849904461-04a58ad377e0?w=800",
      "https://images.unsplash.com/photo-1605236453806-6ff36851218e?w=800",
      "https://images.unsplash.com/photo-1616348436168-de43ad0db179?w=800"
    ],
    createdAt: new Date().toISOString(),
  },
  {
    id: "2",
    title: "Écouteurs Bluetooth Sans Fil Premium",
    description: "Écouteurs sans fil avec réduction de bruit active, autonomie 30h, étanche IPX7. Qualité audio exceptionnelle.",
    price: 89.99,
    moq: 20,
    category: "Électronique",
    status: "Meilleure vente",
    images: [
      "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800",
      "https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=800",
      "https://images.unsplash.com/photo-1613040809024-b4ef7ba99bc3?w=800",
      "https://images.unsplash.com/photo-1608156639585-b3a5a0a0d89d?w=800",
      "https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=800"
    ],
    createdAt: new Date().toISOString(),
  },
  {
    id: "3",
    title: "Montre Connectée Fitness Tracker",
    description: "Montre intelligente avec suivi d'activité, moniteur cardiaque, GPS intégré, résistante à l'eau 5ATM.",
    price: 149.99,
    moq: 15,
    category: "Électronique",
    status: "Vedette",
    images: [
      "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=800",
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800",
      "https://images.unsplash.com/photo-1551816230-ef5deaed4a26?w=800",
      "https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800",
      "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=800"
    ],
    createdAt: new Date().toISOString(),
  },
  {
    id: "4",
    title: "Sac à Dos Business Intelligent",
    description: "Sac à dos anti-vol avec port USB, compartiment laptop 15.6 pouces, résistant à l'eau, design moderne.",
    price: 59.99,
    moq: 25,
    category: "Mode",
    status: "Nouveauté",
    images: [
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800",
      "https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?w=800",
      "https://images.unsplash.com/photo-1577733966973-d680bffd2e80?w=800",
      "https://images.unsplash.com/photo-1622560481157-d13b8b085c96?w=800",
      "https://images.unsplash.com/photo-1491637639811-60e2756cc1c7?w=800"
    ],
    createdAt: new Date().toISOString(),
  },
  {
    id: "5",
    title: "Chargeur Rapide Multi-Ports USB-C",
    description: "Chargeur mural 65W avec 3 ports USB-C et 1 port USB-A, charge rapide pour tous appareils.",
    price: 39.99,
    moq: 30,
    category: "Électronique",
    status: "Vente chaude",
    images: [
      "https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=800",
      "https://images.unsplash.com/photo-1625948515291-69613efd103f?w=800",
      "https://images.unsplash.com/photo-1614795376575-6e4b5b72d6f9?w=800",
      "https://images.unsplash.com/photo-1577803645773-f96470509666?w=800",
      "https://images.unsplash.com/photo-1591290619762-c588024f39b5?w=800"
    ],
    createdAt: new Date().toISOString(),
  },
  {
    id: "6",
    title: "Lunettes de Soleil UV Protection",
    description: "Lunettes de soleil polarisées avec protection UV400, monture légère en aluminium, style unisexe.",
    price: 29.99,
    moq: 50,
    category: "Mode",
    status: "Meilleure vente",
    images: [
      "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=800",
      "https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=800",
      "https://images.unsplash.com/photo-1577803645773-f96470509666?w=800",
      "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=800",
      "https://images.unsplash.com/photo-1473496169904-658ba7c44d8a?w=800"
    ],
    createdAt: new Date().toISOString(),
  },
];

export const categories = [
  { id: "all", label: "Toutes les catégories" },
  { id: "Électronique", label: "Électronique" },
  { id: "Mode", label: "Mode" },
  { id: "Maison", label: "Maison" },
  { id: "Beauté", label: "Beauté" },
  { id: "Sports", label: "Sports" },
  { id: "Jouets", label: "Jouets" },
];
