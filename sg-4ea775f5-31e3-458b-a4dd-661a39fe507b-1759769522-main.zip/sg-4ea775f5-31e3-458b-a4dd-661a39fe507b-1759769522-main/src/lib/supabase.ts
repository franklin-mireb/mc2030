import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://17e2ac26-bb6e-433e-b2a2-b8d6a4f0fc55.supabase.co";
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export const uploadImage = async (file: File, folder: string = "products"): Promise<string> => {
  try {
    const fileExt = file.name.split(".").pop();
    const fileName = `${Math.random().toString(36).substring(2)}-${Date.now()}.${fileExt}`;
    const filePath = `${folder}/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from("product-images")
      .upload(filePath, file);

    if (uploadError) {
      throw uploadError;
    }

    const { data } = supabase.storage
      .from("product-images")
      .getPublicUrl(filePath);

    return data.publicUrl;
  } catch (error) {
    console.error("Error uploading image:", error);
    throw error;
  }
};

export const deleteImage = async (imageUrl: string): Promise<void> => {
  try {
    const path = imageUrl.split("/product-images/")[1];
    if (path) {
      const { error } = await supabase.storage
        .from("product-images")
        .remove([path]);

      if (error) {
        throw error;
      }
    }
  } catch (error) {
    console.error("Error deleting image:", error);
    throw error;
  }
};

export const checkSupabaseConnection = async (): Promise<boolean> => {
  try {
    const { data, error } = await supabase.from("products").select("count").limit(1);
    return !error;
  } catch (error) {
    console.error("Supabase connection error:", error);
    return false;
  }
};

export const WHATSAPP_NUMBER = "+243842267252";

export const sendWhatsAppMessage = (message: string) => {
  const encodedMessage = encodeURIComponent(message);
  const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER.replace(/\+/g, "")}?text=${encodedMessage}`;
  window.open(whatsappUrl, "_blank");
};