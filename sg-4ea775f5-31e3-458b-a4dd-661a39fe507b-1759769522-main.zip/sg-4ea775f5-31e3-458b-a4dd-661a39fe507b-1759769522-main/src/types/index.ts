export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  moq: number;
  category: string;
  status: "Vente chaude" | "Meilleure vente" | "Vedette" | "Nouveauté";
  images: string[];
  imageUrl?: string;
  createdAt: string;
}

export interface Order {
  id: string;
  productId: string;
  productTitle: string;
  productImage: string;
  quantity: number;
  totalPrice: number;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  customerCity: string;
  notes?: string;
  status: "new" | "postponed" | "delivered" | "unreachable" | "rejected";
  createdAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address: string;
  city: string;
  totalOrders: number;
  totalSpent: number;
  createdAt: string;
}

export interface Delivery {
  id: string;
  orderId: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  customerCity: string;
  productTitle: string;
  quantity: number;
  totalPrice: number;
  status: "pending" | "in_transit" | "delivered" | "failed";
  deliveryDate?: string;
  notes?: string;
  createdAt: string;
}