# Guide de Configuration Supabase pour Mireb Commercial

## Étape 1 : Créer un compte Supabase

1. Allez sur [https://supabase.com](https://supabase.com)
2. Cliquez sur "Start your project" ou "Sign Up"
3. Créez un compte avec votre email ou via GitHub

## Étape 2 : Créer un nouveau projet

1. Une fois connecté, cliquez sur "New Project"
2. Remplissez les informations :
   - **Name** : Mireb Commercial
   - **Database Password** : Choisissez un mot de passe fort (notez-le bien !)
   - **Region** : Choisissez la région la plus proche (ex: Europe West pour l'Afrique)
   - **Pricing Plan** : Free (gratuit) suffit pour commencer
3. Cliquez sur "Create new project"
4. Attendez quelques minutes que le projet soit créé

## Étape 3 : Obtenir les clés API

1. Dans votre projet Supabase, allez dans **Settings** (icône d'engrenage dans la sidebar)
2. Cliquez sur **API** dans le menu de gauche
3. Vous verrez deux clés importantes :
   - **Project URL** (ex: `https://xxxxxxxxxxxxx.supabase.co`)
   - **anon/public key** (commence par `eyJ...`)
4. Copiez ces deux valeurs

## Étape 4 : Configurer les variables d'environnement

1. Dans l'interface Softgen, cliquez sur l'icône **⚙️ Settings** en haut à droite
2. Allez dans l'onglet **Environment**
3. Ajoutez ces deux variables :
   ```
   NEXT_PUBLIC_SUPABASE_URL=votre_project_url
   NEXT_PUBLIC_SUPABASE_ANON_KEY=votre_anon_key
   ```
4. Remplacez les valeurs par celles que vous avez copiées
5. Cliquez sur "Save"

## Étape 5 : Créer les tables dans Supabase

1. Dans votre projet Supabase, allez dans **SQL Editor** (dans la sidebar)
2. Cliquez sur **New query**
3. Copiez tout le contenu du fichier `supabase/schema.sql` de votre projet
4. Collez-le dans l'éditeur SQL
5. Cliquez sur **Run** (ou appuyez sur Ctrl+Enter)
6. Vous devriez voir un message de succès

## Étape 6 : Vérifier les tables créées

1. Allez dans **Table Editor** (dans la sidebar)
2. Vous devriez voir ces tables :
   - ✅ products
   - ✅ orders
   - ✅ customers
   - ✅ deliveries
   - ✅ categories
3. La table `categories` devrait déjà contenir 10 catégories par défaut

## Étape 7 : Redémarrer le serveur

1. Dans Softgen, cliquez sur **⚙️ Settings** → **Restart Server**
2. Attendez que le serveur redémarre
3. Votre site utilisera maintenant Supabase au lieu de localStorage !

## Étape 8 : Tester la connexion

1. Allez sur la page d'accueil de votre site
2. Les produits devraient maintenant être stockés dans Supabase
3. Créez un produit dans la section Admin pour tester

## 🎉 C'est terminé !

Votre site Mireb Commercial est maintenant connecté à Supabase. Toutes les données (produits, commandes, clients, livraisons) seront stockées de manière permanente dans votre base de données PostgreSQL.

## Avantages de Supabase

✅ **Données persistantes** : Plus de perte de données au nettoyage du cache
✅ **Temps réel** : Mises à jour automatiques entre appareils
✅ **Sécurité** : Row Level Security (RLS) activé
✅ **Scalabilité** : Peut gérer des milliers de produits et commandes
✅ **Gratuit** : 500 MB de base de données, 2 GB de stockage fichiers
✅ **API automatique** : Pas besoin de coder le backend

## Support

Si vous avez des questions ou des problèmes :
- Documentation Supabase : https://supabase.com/docs
- Support Softgen : Cliquez sur le bouton support dans l'interface
